chmod 755 $MODPATH/system/xbin/pnss
