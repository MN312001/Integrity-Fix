# Remove any definitely conflicting modules that are installed
if [ -d /data/adb/modules/Ttarget ]; then
    touch /data/adb/modules/Ttarget/remove
    ui_print "! Ttarget module will be removed on next reboot"
fi

# Remove any definitely conflicting modules that are installed
if [ -d /data/adb/modules/Hide-Target ]; then
    touch /data/adb/modules/Hide-Target/remove
    ui_print "! Hide-Target module will be removed on next reboot"
fi
echo ''
echo "Installations Root Oneline Communication"
echo ''
sleep 0.5
echo "Telegram with Mohammad Ismail:- @MN312001"
echo ''
sleep 0.4

#keybox Edition
if [ -d "/data/adb/modules/tricky_store" ]; then
    mv /data/adb/tricky_store/keybox.xml /data/adb/tricky_store/keybox.xml.orig
    cp "$MODPATH"/keybox.xml /data/adb/tricky_store/keybox.xml
    ui_print "✅ K-Box file updated 🔑."
fi

echo '' 
sleep 0.3

#target Edition 
if [ -d "/data/adb/modules/tricky_store" ]; then
    mv /data/adb/tricky_store/target.txt /data/adb/tricky_store/target.txt.orig
    cp "$MODPATH"/target.txt /data/adb/tricky_store/target.txt
    ui_print "✅ Hide file updated 📝."
fi

echo ''
sleep 0.2

#security_patch Edition
if [ -d "/data/adb/modules/tricky_store" ]; then
    mv /data/adb/tricky_store/security_patch.txt /data/adb/tricky_store/security_patch.txt.orig
    rm /data/adb/tricky_store/security_patch.txt.orig
    cp "$MODPATH"/security_patch.txt /data/adb/tricky_store/security_patch.txt
    ui_print "✅ security-patch file Add 🔒."
fi

echo '' 
sleep 0.1

# Hiding SELinux | Permissive status
resetprop_if_diff ro.boot.selinux enforcing
if [ -n "$(resetprop ro.build.selinux)" ]; then
    resetprop --delete ro.build.selinux
fi

echo "✅ The file has expired, please restart your mobile phone. 🔑📝🔒"