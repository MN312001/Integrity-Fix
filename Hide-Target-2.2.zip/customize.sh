
ui_print "cleaning environment"
rm -r /data/adb/modules/Ttarget

 if [ -d "/data/adb/modules/tricky_store" ]; then
    mv /data/adb/tricky_store/target.txt /data/adb/tricky_store/target.txt.orig
    rm /data/adb/tricky_store/target.txt.orig
    cp "$MODPATH"/target.txt /data/adb/tricky_store/target.txt
fi